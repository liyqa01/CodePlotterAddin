#if !defined(AFX_CDEDITORDLG_H__B82FB381_3D92_47DA_8F99_E4814716242E__INCLUDED_)
#define AFX_CDEDITORDLG_H__B82FB381_3D92_47DA_8F99_E4814716242E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CDEditorDlg.h : header file
//

#include "..\shared\textdiagramctrl.h"
#include "..\shared\maskedit.h"

#include <afxcmn.h>

/////////////////////////////////////////////////////////////////////////////
// CCDEditorDlg dialog

class CCDEditorDlg : public CDialog
{
// Construction
public:
	CCDEditorDlg(LPCTSTR szDiagram = NULL, CWnd* pParent = NULL);   // standard constructor

	BOOL GetDiagram(CString& sDiagram, LPCTSTR szComment = NULL);
	LPCTSTR GetComment() { return m_sComment; }

protected:
// Dialog Data
	//{{AFX_DATA(CCDEditorDlg)
	CStatic	m_stComment;
	CComboBox	m_cbCommentStyle;
	CString	m_sTitle;
	int		m_nPageWidth;
	//}}AFX_DATA
	CTextDiagramCtrl m_ctrlDiagram;
	CTextDiagram m_diagramBackup;
	CToolBar m_toolbar;

	CString m_sDiagram;
	HICON m_hIcon;
	CSize m_size;
	CString m_sComment;
	BOOL m_bVerified;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCDEditorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();
	virtual void OnCancel();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCDEditorDlg)
	afx_msg void OnChangeTitle();
	afx_msg void OnReset();
	afx_msg void OnDestroy();
	afx_msg void OnDone();
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnDeleteRect();
	afx_msg void OnEditRectText();
	afx_msg void OnNewConn();
	afx_msg void OnNewRect();
	afx_msg void OnChangeComment();
	afx_msg void OnKillfocusPagewidth();
	//}}AFX_MSG
	afx_msg void OnClose();
	afx_msg void OnDiagramSelChange(TDNHDR* pTDHdr, LRESULT* pResult = 0);
	afx_msg void OnDiagramRectMove(TDNHDR* pTDHdr, LRESULT* pResult = 0);
	afx_msg void OnDiagramInternalError(TDNHDR* pTDHdr, LRESULT* pResult = 0);
	afx_msg void OnDiagramDblClk(TDNHDR* pTDHdr, LRESULT* pResult = 0);
	afx_msg void OnDiagramImplNewConn(TDNHDR* pTDHdr, LRESULT* pResult = 0);
	afx_msg BOOL OnNeedTooltip(UINT, NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()

protected:
	BOOL EnableOK(); // returns whether the OK button is enabled or not
	BOOL IsVerified() { return m_bVerified; } // returns whether the current diagram is verified
	virtual void UpdateToolbar();
	virtual void SetDiagram(LPCTSTR szDiagram);
	void EditConnection(int nConn);
	CRect OffsetCtrl(UINT uCtrlID, int cx, int cy);
	CRect OffsetCtrl(CWnd* pCtrl, int cx, int cy);
	CString GetTip(UINT nID) const;
	CString RemoveComments(CStringArray& diagram) const;

	virtual void LoadSettings();
	virtual void SaveSettings();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDEDITORDLG_H__B82FB381_3D92_47DA_8F99_E4814716242E__INCLUDED_)
