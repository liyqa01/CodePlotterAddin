// EditConnectionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "EditConnectionDlg.h"

#include <atlbase.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditConnectionDlg dialog

CEditConnectionDlg::CEditConnectionDlg(const CTextDiagram& diagram, int nRectFrom, int nRectTo, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_EDITCONN_DIALOG, pParent), m_diagram(diagram), m_nRectFrom(nRectFrom), m_nRectTo(nRectTo)
{
	//{{AFX_DATA_INIT(CEditConnectionDlg)
	m_sRectFrom = _T("");
	m_nSideFrom = 0;
	//}}AFX_DATA_INIT

	// restore last 'side from'
	CRegKey reg;
	
	if (reg.Open(HKEY_CURRENT_USER, "Software\\AbstractSpoon\\CodePlotter") == ERROR_SUCCESS)
		reg.QueryValue((DWORD&)m_nSideFrom, "SideFrom");
}


void CEditConnectionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditConnectionDlg)
	DDX_Control(pDX, IDC_RECTLIST, m_cbRectTo);
	DDX_Text(pDX, IDC_RECTFROM, m_sRectFrom);
	DDX_CBIndex(pDX, IDC_SIDES, m_nSideFrom);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditConnectionDlg, CDialog)
	//{{AFX_MSG_MAP(CEditConnectionDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditConnectionDlg message handlers

BOOL CEditConnectionDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// set title
	SetWindowText(m_nRectTo == -1 ? "New Connection" : "Edit Connection");

	// init data
	CTDRect rect;

	if (!m_diagram.GetRect(m_nRectFrom, rect))
	{
		// TODO
		EndDialog(-1);
		return TRUE;
	}

	CString sRectFrom = rect.GetText();

	if (sRectFrom.IsEmpty())
		m_sRectFrom.Format("(%d, %d, %d, %d)", rect.left, rect.top, rect.right, rect.bottom);
	else
	{
		sRectFrom.TrimLeft();
		sRectFrom.TrimRight();
		
		m_sRectFrom.Format("'%s'", sRectFrom);
	}

	if (m_nRectTo != -1)
	{
		CTDConnection conn;
		int nConn = m_diagram.FindConnection(m_nRectFrom, m_nRectTo);

		if (nConn == -1 || !m_diagram.GetConnection(nConn, conn))
		{
			// TODO
			EndDialog(-1);
			return TRUE;
		}

		m_nSideFrom = conn.SideFrom();
	}

	// fill list, excluding existing connections 
	int nRect = 0;
	int nSel = -1;

	while (m_diagram.GetRect(nRect, rect))
	{
		if ((nRect != m_nRectFrom) && (nRect == m_nRectTo || m_diagram.FindConnection(m_nRectFrom, nRect) == -1))
		{
			CString sText = rect.GetText();
			
			if (sText.IsEmpty())
				sText.Format("(%d, %d, %d, %d)", rect.left, rect.top, rect.right, rect.bottom);
			else
			{
				sText.TrimLeft();
				sText.TrimRight();
			}
			
			int nIndex = m_cbRectTo.AddString(sText);
			m_cbRectTo.SetItemData(nIndex, nRect);

			if (nRect == m_nRectTo)
				nSel = nIndex;
		}

		nRect++;
	}

	m_cbRectTo.SetCurSel(nSel);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CEditConnectionDlg::GetConnection(CTDConnection& conn)
{
	if (m_nRectTo == -1)
		return FALSE;

	conn = CTDConnection(m_nRectFrom, m_nRectTo, m_nSideFrom);
	return TRUE;
}

void CEditConnectionDlg::OnOK()
{
	UpdateData();

	int nIndex = m_cbRectTo.GetCurSel();

	if (nIndex != -1)
		m_nRectTo = m_cbRectTo.GetItemData(nIndex);

	// save last 'side from'
	CRegKey reg;
	
	if (reg.Open(HKEY_CURRENT_USER, "Software\\AbstractSpoon\\CodePlotter") == ERROR_SUCCESS)
		reg.SetValue((DWORD)m_nSideFrom, "SideFrom");

	CDialog::OnOK();
}
