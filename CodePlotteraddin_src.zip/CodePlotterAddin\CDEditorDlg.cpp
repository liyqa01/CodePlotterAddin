// CDEditorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "CDEditorDlg.h"
#include "editconnectiondlg.h"

#include <atlbase.h>

#define COMPILE_MULTIMON_STUBS
#include <multimon.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCDEditorDlg dialog

CCDEditorDlg::CCDEditorDlg(LPCTSTR szDiagram, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CDEDITOR_DIALOG, pParent), m_sDiagram(szDiagram), 
	m_size(0, 0), m_nPageWidth(80), m_bVerified(TRUE)
{
	//{{AFX_DATA_INIT(CCDEditorDlg)
	m_sTitle = _T("");
	//}}AFX_DATA_INIT

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_ctrlDiagram.SetPageWidth(m_nPageWidth, FALSE);
}


void CCDEditorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCDEditorDlg)
	DDX_Control(pDX, IDC_COMMENTLABEL, m_stComment);
	DDX_Control(pDX, IDC_COMMENTSTYLE, m_cbCommentStyle);
	DDX_Text(pDX, IDC_TITLE, m_sTitle);
	DDX_Text(pDX, IDC_PAGEWIDTH, m_nPageWidth);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
		m_sComment.Empty();

		int nSel = m_cbCommentStyle.GetCurSel();

		if (nSel > 0)
			m_cbCommentStyle.GetLBText(nSel, m_sComment);
	}
	else
	{
		if (m_sComment.IsEmpty())
			m_cbCommentStyle.SetCurSel(0);
		else
			m_cbCommentStyle.SelectString(-1, m_sComment);
	}
}


BEGIN_MESSAGE_MAP(CCDEditorDlg, CDialog)
	//{{AFX_MSG_MAP(CCDEditorDlg)
	ON_EN_CHANGE(IDC_TITLE, OnChangeTitle)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_DONE, OnDone)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_DELETERECT, OnDeleteRect)
	ON_COMMAND(ID_EDITTEXT, OnEditRectText)
	ON_COMMAND(ID_NEWCONN, OnNewConn)
	ON_COMMAND(ID_NEWRECT, OnNewRect)
	ON_CBN_SELCHANGE(IDC_COMMENTSTYLE, OnChangeComment)
	ON_COMMAND(ID_RESET, OnReset)
	ON_EN_KILLFOCUS(IDC_PAGEWIDTH, OnKillfocusPagewidth)
	//}}AFX_MSG_MAP
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDCLOSE, OnClose)
	ON_NOTIFY(TDN_SELCHANGE, IDC_DIAGRAM, OnDiagramSelChange)
	ON_NOTIFY(TDN_SELRECTMOVE, IDC_DIAGRAM, OnDiagramRectMove)
	ON_NOTIFY(TDN_INTERNALERROR, IDC_DIAGRAM, OnDiagramInternalError)
	ON_NOTIFY(TDN_DBLCLK, IDC_DIAGRAM, OnDiagramDblClk)
	ON_NOTIFY(TDN_IMPLCONNNEW, IDC_DIAGRAM, OnDiagramImplNewConn)
	ON_NOTIFY_EX_RANGE(TTN_NEEDTEXT, 0, 0xFFFF, OnNeedTooltip)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCDEditorDlg message handlers

BOOL CCDEditorDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// toolbar
	CRect rToolbar;
	GetDlgItem(IDC_TB_FRAME)->GetWindowRect(rToolbar);
	ScreenToClient(rToolbar);

	VERIFY (m_toolbar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_BOTTOM | CBRS_TOOLTIPS | CBRS_FLYBY)
			&& m_toolbar.LoadToolBar(IDR_CODEPLOTTER));

	m_toolbar.MoveWindow(rToolbar);

	// very important - turn OFF all the auto positioning and sizing
	// by default have no borders
	int nStyle = m_toolbar.GetBarStyle();

	nStyle &= ~(CCS_NORESIZE | CCS_NOPARENTALIGN);
	nStyle &= ~(CBRS_BORDER_TOP | CBRS_BORDER_BOTTOM | CBRS_BORDER_LEFT | CBRS_BORDER_RIGHT);

	m_toolbar.SetBarStyle(nStyle);

	// icons
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	CRect rect;
	GetDlgItem(IDC_DIAGRAM)->GetWindowRect(rect);
	GetDlgItem(IDC_DIAGRAM)->DestroyWindow();

	ScreenToClient(rect);
	rect.DeflateRect(1, 1);

	m_ctrlDiagram.Create(WS_VISIBLE | WS_CHILD | WS_TABSTOP, rect, this, IDC_DIAGRAM);
	m_ctrlDiagram.ModifyStyleEx(0, WS_EX_CLIENTEDGE);

	rect.InflateRect(1, 1);
	m_ctrlDiagram.MoveWindow(rect);

	if (!m_sDiagram.IsEmpty())
		SetDiagram(m_sDiagram);

	m_sTitle = m_ctrlDiagram.GetTitle();
	UpdateData(FALSE);

	// grab the current diagram as the first backup
	m_diagramBackup.SetDiagram(m_ctrlDiagram);

	EnableOK();
	UpdateToolbar();

	LoadSettings();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCDEditorDlg::OnNewConn() 
{
	int nSelRect = m_ctrlDiagram.GetSelRect();

	if (nSelRect == -1)
		return;

	CEditConnectionDlg dialog(m_ctrlDiagram, nSelRect);

	if (dialog.DoModal() != IDOK)
		return;

	CTDConnection conn;

	if (dialog.GetConnection(conn) && 
		m_ctrlDiagram.AddConnection(nSelRect, conn.RectTo(), conn.SideFrom()) >= 0)
	{
		// update UI
		EnableOK();
	}
	else
		MessageBox("Sorry, the requested connection could not be added.", "CodePlotter");
}

void CCDEditorDlg::EditConnection(int nConn)
{
	CTDConnection conn;

	if (!m_ctrlDiagram.GetConnection(nConn, conn))
		return;

	CEditConnectionDlg dialog(m_ctrlDiagram, conn.RectFrom(), conn.RectTo());

	if (dialog.DoModal() != IDOK)
		return;

	if (dialog.GetConnection(conn) && m_ctrlDiagram.SetConnection(nConn, conn))
	{
		// update UI
		EnableOK();
		UpdateToolbar();
	}
	else
		MessageBox("Sorry, the connection could not be edited as requested.", "CodePlotter");
}

void CCDEditorDlg::OnNewRect() 
{
	if (m_ctrlDiagram.AddRect(NULL, NULL, TRUE) >= 0)
	{
		// refresh UI
		EnableOK();
		UpdateToolbar();
	}
	else
		MessageBox("Sorry, a new rectangle could not be added.", "CodePlotter");
}

void CCDEditorDlg::OnDiagramRectMove(TDNHDR* pTDHdr, LRESULT* pResult)
{
	EnableOK();
	UpdateToolbar();
}

void CCDEditorDlg::OnDiagramSelChange(TDNHDR* pTDHdr, LRESULT* pResult)
{
	UpdateToolbar();
}

void CCDEditorDlg::OnDiagramInternalError(TDNHDR* pTDHdr, LRESULT* pResult)
{
	if (m_diagramBackup.GetRectCount())
	{
		// restore the last backup and message the user
		m_ctrlDiagram.SetDiagram(m_diagramBackup);
		
		MessageBox("Sorry, the last edit could not be completed.\n\nHowever, the diagram was backed-up and has been restored so that you can try the edit again.",
					"CodePlotter Error");

		EnableOK();
	}
}

BOOL CCDEditorDlg::GetDiagram(CString& sDiagram, LPCTSTR szComment)
{
	CStringArray diagram;

	if (m_ctrlDiagram.GetDiagram(diagram))
	{
		sDiagram.Empty();
		CString sLine;

		for (int nLine = 0; nLine < diagram.GetSize(); nLine++)
		{
			sLine.Format("%s%s\r\n", szComment ? szComment : m_sComment, diagram.GetAt(nLine));
			sDiagram += sLine;
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CCDEditorDlg::EnableOK()
{
	m_bVerified = m_ctrlDiagram.VerifyDiagram();

	m_diagramBackup.SetDiagram(m_ctrlDiagram);

	GetDlgItem(IDC_DONE)->EnableWindow(m_bVerified);

	return m_bVerified;
}

void CCDEditorDlg::OnDeleteRect() 
{
	if (m_ctrlDiagram.DeleteRect(m_ctrlDiagram.GetSelRect()))
	{
		// refresh UI
		EnableOK();
		UpdateToolbar();
	}
}

void CCDEditorDlg::OnChangeTitle() 
{
	UpdateData();

	m_ctrlDiagram.SetTitle(m_sTitle);
}

void CCDEditorDlg::OnReset() 
{
	if (m_ctrlDiagram.ResetDiagram())
	{
		m_diagramBackup.ResetDiagram();
		UpdateToolbar();
	}
}

void CCDEditorDlg::SetDiagram(LPCTSTR szDiagram)
{
	// convert raw text to lines
	CStringArray diagram;
	CTextDiagram::ConvertDiagram(szDiagram, diagram);

	// remove and cache the leading comment if any and if not previously set
	if (m_sComment.IsEmpty())
		m_sComment = RemoveComments(diagram);
	else
		RemoveComments(diagram);

	// pass to the text diagram
	m_ctrlDiagram.SetPageWidth(m_nPageWidth - m_sComment.GetLength());
	m_ctrlDiagram.SetDiagram(diagram);

	// save the title
	m_sTitle = m_ctrlDiagram.GetTitle();
	UpdateData(FALSE);

	// grab the current diagram as the first backup
	m_diagramBackup.SetDiagram(m_ctrlDiagram);
}

void CCDEditorDlg::OnDiagramDblClk(TDNHDR* pTDHdr, LRESULT* pResult)
{
	CPoint point(pTDHdr->ptCursor);

	int nConn = m_ctrlDiagram.HitTestConn(point);

	if (nConn != -1)
		EditConnection(nConn);
}

void CCDEditorDlg::OnDiagramImplNewConn(TDNHDR* pTDHdr, LRESULT* pResult)
{
	int nSelRect = m_ctrlDiagram.GetSelRect();

	if (nSelRect == -1)
		return;

	CEditConnectionDlg dialog(m_ctrlDiagram, nSelRect);

	if (dialog.DoModal() != IDOK)
		return;

	CTDConnection conn;

	if (dialog.GetConnection(conn) && 
		m_ctrlDiagram.AddConnection(nSelRect, conn.RectTo(), conn.SideFrom()) >= 0)
	{
		// update UI
		EnableOK();
		UpdateToolbar(); 
	}
	else
		MessageBox("Sorry, the requested connection could not be added.", "CodePlotter");
}

void CCDEditorDlg::LoadSettings()
{
	CRegKey reg;
	
	if (reg.Open(HKEY_CURRENT_USER, "Software\\AbstractSpoon\\CodePlotter") == ERROR_SUCCESS)
	{
		// pos
		WINDOWPLACEMENT wp;
		GetWindowPlacement(&wp);

		DWORD dwTopLeft = -1, dwBottomRight = -1;
		reg.QueryValue(dwTopLeft, "TopLeft");
		reg.QueryValue(dwBottomRight, "BottomRight");

		if (dwTopLeft != -1 && dwBottomRight != -1)
		{
			CRect rect(LOWORD(dwTopLeft), HIWORD(dwTopLeft), LOWORD(dwBottomRight), HIWORD(dwBottomRight));

			// ensure this intersects with the desktop
			if (NULL != MonitorFromRect(rect, MONITOR_DEFAULTTONULL))
			{
				wp.rcNormalPosition = rect;
				wp.showCmd = SW_HIDE;

				SetWindowPlacement(&wp);
			}
		}

		// comment
		if (m_ctrlDiagram.IsEmpty())
		{
			DWORD dwLen = 32;

			reg.QueryValue(m_sComment.GetBuffer(dwLen), "Comment", &dwLen);
			m_sComment.ReleaseBuffer();

			if (m_sComment.IsEmpty() || (CB_ERR == m_cbCommentStyle.SelectString(-1, m_sComment)))
			{
				m_sComment.Empty();
				m_cbCommentStyle.SetCurSel(0);
			}
		}

		reg.QueryValue((DWORD&)m_nPageWidth, "PageWidth");
		m_ctrlDiagram.SetPageWidth(m_nPageWidth - m_sComment.GetLength());
	}

	UpdateData(FALSE);
}

void CCDEditorDlg::SaveSettings()
{
	UpdateData();

	CRegKey reg;
	
	if (reg.Open(HKEY_CURRENT_USER, "Software\\AbstractSpoon\\CodePlotter") == ERROR_SUCCESS)
	{
		// pos
		WINDOWPLACEMENT wp;
		GetWindowPlacement(&wp);

		reg.SetValue(MAKELPARAM(wp.rcNormalPosition.left, wp.rcNormalPosition.top), "TopLeft");
		reg.SetValue(MAKELPARAM(wp.rcNormalPosition.right, wp.rcNormalPosition.bottom), "BottomRight");

		// comment
		CString sComment; // "" by default
		int nSel = m_cbCommentStyle.GetCurSel();

		if (nSel > 0)
			m_cbCommentStyle.GetLBText(nSel, sComment);

		reg.SetValue(sComment, "Comment");
		reg.SetValue(m_nPageWidth, "PageWidth");
	}
}

void CCDEditorDlg::OnDestroy() 
{
	SaveSettings();

	CDialog::OnDestroy();
}

void CCDEditorDlg::OnOK()
{
}

void CCDEditorDlg::OnCancel()
{
}

void CCDEditorDlg::OnClose() 
{
	EndDialog(IDCANCEL);
	
	CDialog::OnClose();
}

void CCDEditorDlg::OnDone() 
{
	EndDialog(IDOK);
	
	OnOK(); // virtual call
}

void CCDEditorDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// repos all the controls
	if (nType != SIZE_MINIMIZED)
	{
		if (m_size.cx && m_size.cy)
		{
	//		OffsetCtrl(IDC_TITLELABEL, 0, cy - m_size.cy);
			CRect rTitle = OffsetCtrl(IDC_TITLE, 0, 0);
			rTitle.right += (cx - m_size.cx);
			GetDlgItem(IDC_TITLE)->MoveWindow(rTitle);
		
			OffsetCtrl(IDC_COMMENTSTYLE, 0, cy - m_size.cy);
			OffsetCtrl(IDC_COMMENTLABEL, 0, cy - m_size.cy);
			OffsetCtrl(IDC_PAGEWIDTH, 0, cy - m_size.cy);
			OffsetCtrl(IDC_PAGEWIDTHLABEL, 0, cy - m_size.cy);
			OffsetCtrl(IDC_RESET, 0, cy - m_size.cy);
			OffsetCtrl(IDC_DONE, cx - m_size.cx, cy - m_size.cy);
			OffsetCtrl(IDCLOSE, cx - m_size.cx, cy - m_size.cy);

			CRect rToolbar = OffsetCtrl(IDC_TB_FRAME, 0, cy - m_size.cy);
			m_toolbar.MoveWindow(rToolbar);

			CRect rDiagram = OffsetCtrl(IDC_DIAGRAM, 0, 0);
			rDiagram.right += cx - m_size.cx;
			rDiagram.bottom += cy - m_size.cy;
			GetDlgItem(IDC_DIAGRAM)->MoveWindow(rDiagram);
		}

		m_size.cx = cx;
		m_size.cy = cy;

		Invalidate(FALSE);
	}
}

CRect CCDEditorDlg::OffsetCtrl(UINT uCtrlID, int cx, int cy)
{
	return OffsetCtrl(GetDlgItem(uCtrlID), cx, cy);
}

CRect CCDEditorDlg::OffsetCtrl(CWnd* pCtrl, int cx, int cy)
{
	if (pCtrl)
	{
		CRect rChild;
		pCtrl->GetWindowRect(rChild);
		pCtrl->GetParent()->ScreenToClient(rChild);

		rChild.OffsetRect(cx, cy);
		pCtrl->MoveWindow(rChild);

		return rChild;
	}

	return CRect(0, 0, 0, 0);
}

void CCDEditorDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);

	// arbitrary
	lpMMI->ptMinTrackSize.x = 500;
	lpMMI->ptMinTrackSize.y = 450;
}

BOOL CCDEditorDlg::OnNeedTooltip(UINT, NMHDR* pNMHDR, LRESULT* pResult)
{
    ASSERT(pNMHDR->code == TTN_NEEDTEXT);

    // to be thorough we will need to handle UNICODE versions of the message also !!
    TOOLTIPTEXT* pTTT = (TOOLTIPTEXT*)pNMHDR;
 
	UINT nID = pNMHDR->idFrom;

    if (pTTT->uFlags & TTF_IDISHWND)
    {
        // idFrom is actually the HWND of the tool 
        nID = ::GetDlgCtrlID((HWND)nID);
    }

    CString strTipText = GetTip(nID);

    if (!strTipText.IsEmpty()) // will be zero on a separator
    {
        lstrcpyn(pTTT->szText, strTipText, sizeof(pTTT->szText));

        *pResult = 0;

        return TRUE;
    }

    return FALSE;
}

CString CCDEditorDlg::GetTip(UINT nID) const
{
	if (!nID)
		return "";

	CString sPrompt, sTip;
	sPrompt.LoadString(nID);
	
	if (sPrompt.IsEmpty())
		return "";
	
	// tip text starts at '\n' 
	int nStartTip = sPrompt.Find('\n');
	
	if (nStartTip != -1) 
		sPrompt = sPrompt.Right(sPrompt.GetLength() - nStartTip - 1);
	
	// strip '&' and '...' if present
	int nLen = sPrompt.GetLength();
	
	for (int nPos = 0; nPos < nLen; nPos++)
		if (sPrompt[nPos] != '&' && sPrompt[nPos] != '.')
			sTip += sPrompt[nPos];
		
	return sTip;
}

void CCDEditorDlg::OnEditRectText() 
{
	m_ctrlDiagram.EditSelectedText();
}

void CCDEditorDlg::UpdateToolbar()
{
	int nSel = m_ctrlDiagram.GetSelRect();

	m_toolbar.GetToolBarCtrl().EnableButton(ID_RESET, !m_ctrlDiagram.IsEmpty());
	m_toolbar.GetToolBarCtrl().EnableButton(ID_NEWCONN, nSel != -1 && m_ctrlDiagram.GetRectCount() > 1);
	m_toolbar.GetToolBarCtrl().EnableButton(ID_EDITTEXT, nSel != -1 && !m_ctrlDiagram.EditingText());
	m_toolbar.GetToolBarCtrl().EnableButton(ID_DELETERECT, nSel != -1);
}

CString CCDEditorDlg::RemoveComments(CStringArray& diagram) const
{
	if (!diagram.GetSize())
		return "";

	CString sComment;

	// work our way along the first line until we hit the first character which is not the same in all subsequect lines
	CString sLine(diagram[0]);
	BOOL bSame = TRUE;
	 
	for (int nChar = 0; bSame && nChar < sLine.GetLength(); nChar++)
	{
		char c = sLine[nChar];

		for (int nLine = 1; bSame && nLine < diagram.GetSize(); nLine++)
		{
			CString sLineRest(diagram[nLine]);
			bSame = sLineRest.IsEmpty() ? FALSE : (sLineRest[nChar] == c);
		} 

		if (bSame)
			sComment += c;
	}

	sComment.TrimRight();

	// now remove the comments
	if (!sComment.IsEmpty())
	{
		int nOffset = sComment.GetLength();

		for (int nLine = 0; bSame && nLine < diagram.GetSize(); nLine++)
		{
			CString sLine = diagram[nLine];
			diagram.SetAt(nLine, sLine.Mid(nOffset));
		}
	}

	return sComment;
}

void CCDEditorDlg::OnChangeComment() 
{
	UpdateData();

	m_ctrlDiagram.SetPageWidth(m_nPageWidth - m_sComment.GetLength());
}


void CCDEditorDlg::OnKillfocusPagewidth() 
{
	UpdateData();

	m_ctrlDiagram.SetPageWidth(m_nPageWidth - m_sComment.GetLength());
}
