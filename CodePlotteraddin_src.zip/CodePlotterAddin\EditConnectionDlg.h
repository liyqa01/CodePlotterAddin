#if !defined(AFX_EDITCONNECTIONDLG_H__871B4004_CD59_4DC5_9DFA_4593F4A8197F__INCLUDED_)
#define AFX_EDITCONNECTIONDLG_H__871B4004_CD59_4DC5_9DFA_4593F4A8197F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditConnectionDlg.h : header file
//

#include "..\shared\textdiagram.h"
 
/////////////////////////////////////////////////////////////////////////////
// CEditConnectionDlg dialog

class CEditConnectionDlg : public CDialog
{
// Construction
public:
	CEditConnectionDlg(const CTextDiagram& diagram, int nRectFrom, int nRectTo = -1, CWnd* pParent = NULL);   // standard constructor

	BOOL GetConnection(CTDConnection& conn);

protected:
// Dialog Data
	//{{AFX_DATA(CEditConnectionDlg)
	CComboBox	m_cbRectTo;
	CString	m_sRectFrom;
	int		m_nSideFrom;
	//}}AFX_DATA

	int m_nRectFrom;
	int	m_nRectTo;
	CTextDiagram m_diagram;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditConnectionDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	virtual void OnOK();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditConnectionDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITCONNECTIONDLG_H__871B4004_CD59_4DC5_9DFA_4593F4A8197F__INCLUDED_)
