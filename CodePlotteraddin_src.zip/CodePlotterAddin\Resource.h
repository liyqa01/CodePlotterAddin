//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CodePlotterAddin.rc
//
#define IDS_CODEPLOTTERADDIN_LONGNAME   1
#define IDS_CODEPLOTTERADDIN_DESCRIPTION 2
#define IDS_CMD_STRING                  3
#define IDC_COPY                        103
#define IDR_TOOLBAR_MEDIUM              128
#define IDR_TOOLBAR_LARGE               129
#define IDD_CDEDITOR_DIALOG             129
#define IDR_TRAYPOPUP                   129
#define IDR_MAINFRAME                   130
#define IDD_EDITCONN_DIALOG             131
#define IDD_CDEDITOR_DIALOG1            132
#define IDR_CODEPLOTTER                 132
#define IDC_RESET                       1000
#define IDC_SIZETOP                     1003
#define IDC_DONE                        1003
#define IDC_SIZEBOTTOM                  1004
#define IDC_TITLELABEL                  1004
#define IDC_SIZERIGHT                   1005
#define IDC_SIZELEFT                    1006
#define IDC_TB_FRAME                    1006
#define IDC_TEXT                        1007
#define IDC_DIAGRAM                     1008
#define IDC_MOVEHORZ                    1009
#define IDC_COMMENTLABEL                1009
#define IDC_PAGEWIDTH                   1010
#define IDC_PAGEWIDTHLABEL              1011
#define IDC_MOVEVERT                    1012
#define IDC_CONNECTIONS                 1014
#define IDC_NEWCONNECTION               1015
#define IDC_EDITCONNECTION              1016
#define IDC_NEWRECT                     1018
#define IDC_DELETERECT                  1019
#define IDC_DELETECONNECTION            1020
#define IDC_SIDES                       1021
#define IDC_RECTFROM                    1022
#define IDC_RECTLIST                    1023
#define IDC_TITLE                       1024
#define IDC_SELECTEDITEM                1025
#define ID_TRAY_OPEN                    32771
#define ID_TRAY_EXIT                    32772
#define ID_RESET                        32773
#define ID_COPYDIAGRAM                  32775
#define ID_BUTTON32776                  32776
#define ID_BUTTON32778                  32778
#define ID_BUTTON32781                  32781
#define ID_BUTTON32782                  32782
#define ID_BUTTON32784                  32784
#define ID_NEWRECT                      32785
#define ID_EDITTEXT                     32786
#define ID_DELETERECT                   32787
#define ID_NEWCONN                      32788
#define ID_USECOMMENTS                  32790
#define ID_USECPPCOMMENTS               32791
#define IDC_COMMENTSTYLE                32792

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
