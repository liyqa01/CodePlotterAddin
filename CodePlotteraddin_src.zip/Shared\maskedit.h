#if !defined(AFX_MASKEDIT_H__03CD6C84_2D70_4E44_9E7E_5673B6F6F97E__INCLUDED_)
#define AFX_MASKEDIT_H__03CD6C84_2D70_4E44_9E7E_5673B6F6F97E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// maskedit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMaskEdit window

class CMaskEdit : public CEdit
{
// Construction
public:
	CMaskEdit(LPCTSTR szMask, BOOL bExclude = FALSE);

	void SetMask(LPCTSTR szMask, BOOL bExclude = FALSE) { m_sMask = szMask; m_bExclude = bExclude; }

protected:
	CString m_sMask;
	BOOL m_bExclude;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMaskEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMaskEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMaskEdit)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MASKEDIT_H__03CD6C84_2D70_4E44_9E7E_5673B6F6F97E__INCLUDED_)
