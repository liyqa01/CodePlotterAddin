// maskedit.cpp : implementation file
//

#include "stdafx.h"
#include "maskedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMaskEdit

CMaskEdit::CMaskEdit(LPCTSTR szMask, BOOL bExclude) : m_sMask(szMask), m_bExclude(bExclude)
{
}

CMaskEdit::~CMaskEdit()
{
}


BEGIN_MESSAGE_MAP(CMaskEdit, CEdit)
	//{{AFX_MSG_MAP(CMaskEdit)
	ON_WM_CHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMaskEdit message handlers

void CMaskEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (m_bExclude && m_sMask.Find(nChar) != -1)
		return;

	else if (!m_bExclude && m_sMask.Find(nChar) == -1)
		return;

	CEdit::OnChar(nChar, nRepCnt, nFlags);
}
