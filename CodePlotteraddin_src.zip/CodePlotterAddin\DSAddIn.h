// DSAddIn.h : header file
//

#if !defined(AFX_DSADDIN_H__1CE657AF_EDC0_408E_BAF6_32BA6A4ACB83__INCLUDED_)
#define AFX_DSADDIN_H__1CE657AF_EDC0_408E_BAF6_32BA6A4ACB83__INCLUDED_

#include "commands.h"

// {91FB7B53-0ACC-49F7-A698-E4520CDAAB66}
DEFINE_GUID(CLSID_DSAddIn,
0x91fb7b53, 0xacc, 0x49f7, 0xa6, 0x98, 0xe4, 0x52, 0xc, 0xda, 0xab, 0x66);

/////////////////////////////////////////////////////////////////////////////
// CDSAddIn

class CDSAddIn : 
	public IDSAddIn,
	public CComObjectRoot,
	public CComCoClass<CDSAddIn, &CLSID_DSAddIn>
{
public:
	DECLARE_REGISTRY(CDSAddIn, "CodePlotterAddin.DSAddIn.1",
		"CODEPLOTTERADDIN Developer Studio Add-in", IDS_CODEPLOTTERADDIN_LONGNAME,
		THREADFLAGS_BOTH)

	CDSAddIn() {}
	BEGIN_COM_MAP(CDSAddIn)
		COM_INTERFACE_ENTRY(IDSAddIn)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CDSAddIn)

// IDSAddIns
public:
	STDMETHOD(OnConnection)(THIS_ IApplication* pApp, VARIANT_BOOL bFirstTime,
		long dwCookie, VARIANT_BOOL* OnConnection);
	STDMETHOD(OnDisconnection)(THIS_ VARIANT_BOOL bLastTime);

protected:
	CCommandsObj* m_pCommands;
	DWORD m_dwCookie;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSADDIN_H__1CE657AF_EDC0_408E_BAF6_32BA6A4ACB83__INCLUDED)
