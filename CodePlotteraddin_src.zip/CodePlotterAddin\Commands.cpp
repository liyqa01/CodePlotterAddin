// Commands.cpp : implementation file
//

#include "stdafx.h"
#include "CodePlotterAddin.h"
#include "Commands.h"
#include "cdeditordlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCommands

CCommands::CCommands()
{
	m_pApplication = NULL;
}

CCommands::~CCommands()
{
	ASSERT (m_pApplication != NULL);
	m_pApplication->Release();
}

void CCommands::SetApplicationObject(IApplication* pApplication)
{
	// This function assumes pApplication has already been AddRef'd
	//  for us, which CDSAddIn did in its QueryInterface call
	//  just before it called us.
	m_pApplication = pApplication;
}


/////////////////////////////////////////////////////////////////////////////
// CCommands methods

#define DIAGRAMSTART "{{DIAGRAM_START"
#define DIAGRAMEND "}}DIAGRAM_END"
#define BDIAGRAMSTART L"{{DIAGRAM_START"
#define BDIAGRAMEND L"}}DIAGRAM_END"

STDMETHODIMP CCommands::CodePlotterAddinCommandMethod() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Replace this with the actual code to execute this command
	//  Use m_pApplication to access the Developer Studio Application object,
	//  and VERIFY_OK to see error strings in DEBUG builds of your add-in
	//  (see stdafx.h)
	VERIFY_OK(m_pApplication->EnableModeless(VARIANT_FALSE));

	DoDiagram();

	VERIFY_OK(m_pApplication->EnableModeless(VARIANT_TRUE));

	return S_OK;
}

void CCommands::DoDiagram()
{
	IDocuments* pDocs = NULL;

	if (SUCCEEDED(m_pApplication->get_Documents((IDispatch**)&pDocs)) && pDocs)
	{
		long lCount = 0;

		if (SUCCEEDED(pDocs->get_Count(&lCount)) && lCount)
		{
			// make sure the current document is text
			ITextDocument* pDoc = NULL;

			if (SUCCEEDED(m_pApplication->get_ActiveDocument((IDispatch**)&pDoc)) && pDoc)
			{
				CComBSTR bsType;

				if (SUCCEEDED(pDoc->get_Type(&bsType)))
				{
					CString sType = bsType;

					if (sType == "Text")
					{
						// search back from the current selection looking for the start of a diagram 
						ITextSelection* pSelection = NULL;
						
						if (SUCCEEDED(pDoc->get_Selection((IDispatch**)&pSelection)) && pSelection)
						{
							// save the current insertion point
							int nLineSel = 0;

							VERIFY(SUCCEEDED(pSelection->get_TopLine((long*)&nLineSel)));

							// select all
							pSelection->Cancel();
							pSelection->SelectAll();

							// get the text for the entire document and locate the diagram at the cursor pos
							CComBSTR bsText;
							CString sText;

							BOOL bContinue = TRUE;
							BOOL bGotText = SUCCEEDED(pSelection->get_Text(&bsText));
							BOOL bNew = TRUE;

							// move the selection back to where it was originally
							pSelection->GoToLine((long)nLineSel, CComVariant(dsMove));

							if (bGotText)
							{
								bNew = !FindDiagram(CString(bsText), nLineSel);
							}
							else
							{
								// TODO
								bContinue = FALSE;
							}

							if (bContinue)
							{
								CString sDiagram;
								
								// if we are editing then select the diagram (so we can later replace it)
								if (!bNew)
								{
									VARIANT_BOOL bFoundStart(FALSE), bFoundEnd(FALSE);
									
									// end then start so we finish where we want to start selecting
									pSelection->FindText(BDIAGRAMEND, CComVariant(dsMatchForward), &bFoundEnd);
									pSelection->FindText(BDIAGRAMSTART, CComVariant(dsMatchBackward), &bFoundStart);

									ASSERT (bFoundStart && bFoundEnd);
								
									if (bFoundStart && bFoundEnd)
									{
										// go to start of line
										pSelection->StartOfLine(CComVariant(dsFirstColumn), CComVariant(dsMove));

										do
										{
											// walk the text line by line until we find the end marker
											pSelection->LineDown(CComVariant(dsExtend), CComVariant(1));
											
											CComBSTR bsText;
											CString sPrevText(sDiagram);
											
											if (SUCCEEDED(pSelection->get_Text(&bsText)))
												sDiagram = bsText;
											else
												break;

											// if no change then break
											if (sPrevText == sDiagram)
												break;
										}
										while (sDiagram.Find(DIAGRAMEND) == -1);

										if (sDiagram.Find(DIAGRAMEND) != -1)
										{
											// remove the start and end lines
											int nFindStart = sDiagram.Find("\r\n");
											ASSERT (nFindStart != -1);

											int nFindEnd = sDiagram.ReverseFind('\r');
											ASSERT (nFindEnd != -1);

											sDiagram = sDiagram.Mid(nFindStart + 2, nFindEnd - (nFindStart + 2));
										}
									}
								}

								CString sComment;

								if (EditDiagram(sDiagram, sComment) && (!bNew || !sDiagram.IsEmpty()))
								{
									// add back the comments 
									CString sTemp(sDiagram);
									sDiagram.Format("%s%s\r\n%s%s%s\r\n", sComment, DIAGRAMSTART, sDiagram, sComment, DIAGRAMEND);

									// replace the selection
									pSelection->put_Text(CComBSTR(sDiagram));
								}
								else
									pSelection->Cancel();
							}

							pSelection->Release();
						}
					}
					else
						MessageBox(NULL, "Please open a text document and try again", "CodeDiagrammer", MB_OK);
				}
				else
					MessageBox(NULL, "Please open a text document and try again", "CodeDiagrammer", MB_OK);

				pDoc->Release();
			}
			else
				MessageBox(NULL, "Please open a text document and try again", "CodeDiagrammer", MB_OK);
		}
		else
			MessageBox(NULL, "Please open a text document and try again", "CodeDiagrammer", MB_OK);

		pDocs->Release();
	}
	else
		MessageBox(NULL, "Please open a text document and try again", "CodeDiagrammer", MB_OK);
}

BOOL CCommands::FindDiagram(const CString& sText, int nLineSel)
{
	// search the text looking for a diagram which straddles nLineSel line by line
	int nLineStart = 0, nLineEnd = sText.Find("\r\n");
	int nLine = 1; // vc line numbers start at 1
	int nFindStart = -1, nFindEnd = -1;

	while (nLineEnd != -1)
	{
		CString sLine = sText.Mid(nLineStart, (nLineEnd - nLineStart));

		if (nFindStart == -1 && sLine.Find(DIAGRAMSTART) >= 0)
			nFindStart = nLine;

		else if (nFindStart != -1 && sLine.Find(DIAGRAMEND) >= 0)
			nFindEnd = nLine;

		if (nFindStart != -1 && nFindEnd != -1)
		{
			if (nLineSel >= nFindStart && nLineSel <= nFindEnd)
				return TRUE;
			
			// else
			nFindStart = nFindEnd = -1;
		}

		// next line
		nLineStart = nLineEnd + 2;
		nLineEnd = sText.Find("\r\n", nLineEnd + 2);
		nLine++;
	}

	return FALSE;
}

BOOL CCommands::EditDiagram(CString& sDiagram, CString& sComment)
{
	CCDEditorDlg dialog(sDiagram);

	if (dialog.DoModal() == IDOK)
	{
		sComment = dialog.GetComment();
		return dialog.GetDiagram(sDiagram);
	}

	return FALSE;
}
