// Commands.h : header file
//

#if !defined(AFX_COMMANDS_H__2A13FE4F_45FC_4327_974E_0F71D9829C49__INCLUDED_)
#define AFX_COMMANDS_H__2A13FE4F_45FC_4327_974E_0F71D9829C49__INCLUDED_

#include "CodePlotterAddinTypes.h"

class CCommands : 
	public CComDualImpl<ICommands, &IID_ICommands, &LIBID_CodePlotterAddin>, 
	public CComObjectRoot,
	public CComCoClass<CCommands, &CLSID_Commands>
{
protected:
	IApplication* m_pApplication;

public:
	CCommands();
	~CCommands();
	void SetApplicationObject(IApplication* m_pApplication);

	BEGIN_COM_MAP(CCommands)
		COM_INTERFACE_ENTRY(IDispatch)
		COM_INTERFACE_ENTRY(ICommands)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CCommands)

public:
// ICommands methods
	STDMETHOD(CodePlotterAddinCommandMethod)(THIS);

protected:
	void DoDiagram();
	BOOL EditDiagram(CString& sDiagram, CString& sComment);
	BOOL FindDiagram(const CString& sText, int nLineSel);

};

typedef CComObject<CCommands> CCommandsObj;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMANDS_H__2A13FE4F_45FC_4327_974E_0F71D9829C49__INCLUDED)
